#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Number:190410102\nsubject No.1-program No.2\n\n");
    char a;
    int i=1;
    scanf("%c",&a);
    a=a-32;
    for (1;i<=4;i++)
    {
        printf("%c %c %c %c %c %c %c %c\n %c %c %c %c %c %c %c %c\n",a,a,a,a,a,a,a,a,a,a,a,a,a,a,a,a);

    }
    printf("THE END OF PROGRAM\n");
    return 0;
}
