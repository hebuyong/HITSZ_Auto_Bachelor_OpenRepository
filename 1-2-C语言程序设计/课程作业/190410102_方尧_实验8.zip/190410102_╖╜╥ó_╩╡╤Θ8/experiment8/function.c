#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "function.h"
#define MAX_EMPLOYEE 30
#define MAX_NAMELINE 21


void PrintfChoice()/**��ӡ��ʾ**/
{
    printf("=================================================\n");
    printf("01.Input record\n02.delete record(by employee ID)\n03.search by name\n04.Search by ID\n05.Search by hire date\n"
           "06.Modify record\n07.Statistic\n08.Sort record in descending by ID\n09.Sort record in descending by name\n"
           "10.Sort record in descending by hire date\n11.List record\n0.Exit\n");
    printf("=================================================\n");
    printf("Please input your choice:");
}

int  Getemployee_num()/**�õ��ļ��ڳ�Ա����**/
{
    int result;
    FILE *fp=NULL;
    if((fp=fopen("staff.txt","r"))!=NULL)
    {
        fseek(fp,0,2);
        result=ftell(fp)/sizeof(EMPLOY);
    }
    else
    {
        printf("FAIL TO OPEN FILE OR NOT EXIST!\n");
        fp=fopen("staff.txt","w");
        result=0;

    }
    while((fclose(fp))!=0)
    {
        printf("FAIL TO CLOSE FILE!\n");
        exit(1);
    }
    return result;
}

void Inputdate(int num,EMPLOY emp[])/**��������**/
{
    int i,ret;
    for(i=0; i<=num-1; i++)
    {
        while(getchar()!='\n');
        printf("Please input employee name.(max=20)\n");
        gets(emp[i].name);
        printf("Please input employee's ID, hiredate(year,month,day) and salary:\n");
        ret=scanf("%d,%d,%d,%d,%f",&emp[i].ID,&emp[i].hiredate.year,&emp[i].hiredate.month,&emp[i].hiredate.day,&emp[i].salary);
        while(ret!=5||emp[i].salary<5000-1e-5||emp[i].salary>20000+1e-5)
        {
            printf("Please input salary between 5000 and 20000:\n");
            while(getchar()!='\n');
            printf("Please input employee name.(max=20)\n");
            gets(emp[i].name);
            printf("Please input employee ID hiredate(year,month,day) and salary:\n");
            ret=scanf("%d,%d,%d,%d,%f",&emp[i].ID,&emp[i].hiredate.year,&emp[i].hiredate.month,&emp[i].hiredate.day,&emp[i].salary);
        }
        while(ret!=5||emp[i].hiredate.month<1||emp[i].hiredate.month>12)
        {
            printf("Please input hiredate's month between 1 and 12:\n");
            while(getchar()!='\n');
            printf("Please input employee name.(max=20)\n");
            gets(emp[i].name);
            printf("Please input employee ID hiredate(year,month,day) and salary:\n");
            ret=scanf("%d,%d,%d,%d,%f",&emp[i].ID,&emp[i].hiredate.year,&emp[i].hiredate.month,&emp[i].hiredate.day,&emp[i].salary);
        }
        while(ret!=5||emp[i].hiredate.day<1||emp[i].hiredate.day>31)
        {
            printf("Please input hiredate's day between 1 and 31:\n");
            while(getchar()!='\n');
            printf("Please input employee name.(max=20)\n");
            gets(emp[i].name);
            printf("Please input employee ID hiredate(year,month,day) and salary:\n");
            ret=scanf("%d,%d,%d,%d,%f",&emp[i].ID,&emp[i].hiredate.year,&emp[i].hiredate.month,&emp[i].hiredate.day,&emp[i].salary);
        }
    }
}

void Addinfile(int num,EMPLOY emp[])/**���ṹ�����������ļ���**/
{
    FILE *fp=NULL;
    if((fp=fopen("staff.txt","a"))!=NULL)
    {
        fwrite(emp,sizeof(EMPLOY),num,fp);
    }
    else
    {
        printf("FAIL TO OPEN FILE!\n");
        exit(1);

    }
    while((fclose(fp))!=0)
    {
        printf("FAIL TO CLOSE FILE!\n");
        exit(1);
    }
}
void Copyinfile(int num,EMPLOY emp[])/**���ṹ�����鸴�Ƶ��ļ���**/
{
    FILE *fp=NULL;
    if((fp=fopen("staff.txt","w"))!=NULL)
    {
        fwrite(emp,sizeof(EMPLOY),num,fp);
    }
    else
    {
        printf("FAIL TO OPEN FILE!\n");
        exit(1);

    }
    while((fclose(fp))!=0)
    {
        printf("FAIL TO CLOSE FILE!\n");
        exit(1);
    }
}

void Copyoutfile(int num,EMPLOY emp[])/**���ļ����ݿ����ṹ��������**/
{
    FILE *fp=NULL;
    if((fp=fopen("staff.txt","r"))!=NULL)
    {
        fread(emp,sizeof(EMPLOY),num,fp);
    }
    else
    {
        printf("FAIL TO OPEN FILE!\n");
        exit(1);

    }
    while((fclose(fp))!=0)
    {
        printf("FAIL TO CLOSE FILE!\n");
        exit(1);
    }
}

int Deletedate(int n,int num,EMPLOY emp[])/**ɾ���ļ�**/
{
    emp[n].ID=0;
    OrderbyID(num,emp);
    return 0;
}

void OrderbyID(int num,struct Employ emp[])/**ID����**/
{
    int listmax,i,j;
    EMPLOY temp;
    for(i=0; i<=num-2; i++)
    {
        listmax=i;
        for(j=i+1; j<=num-1; j++)
        {
            if(emp[j].ID>emp[listmax].ID)
            {
                listmax=j;
            }
        }
        if(listmax!=i)
        {
            temp=emp[i];
            emp[i]=emp[listmax];
            emp[listmax]=temp;
        }
    }
}
void Orderbyname(int num,struct Employ emp[])/**��������**/
{
    int listmax,i,j;
    EMPLOY temp;
    for(i=0; i<=num-2; i++)
    {
        listmax=i;
        for(j=i+1; j<=num-1; j++)
        {
            if(strcmp(emp[j].name,emp[listmax].name)<0)
            {
                listmax=j;
            }
        }
        if(listmax!=i)
        {
            temp=emp[i];
            emp[i]=emp[listmax];
            emp[listmax]=temp;
        }
    }
}

void Orderbyhiredate(int num,EMPLOY emp[])/**��ְ��������**/
{
    int listmax,i,j;
    EMPLOY temp;
    for(i=0; i<=num-2; i++)
    {
        listmax=i;
        for(j=i+1; j<=num-1; j++)
        {
            if(emp[j].hiredate.year>emp[listmax].hiredate.year)
            {
                listmax=j;
            }
        }
        if(listmax!=i)
        {
            temp=emp[i];
            emp[i]=emp[listmax];
            emp[listmax]=temp;
        }
    }
    for(i=0; i<=num-2; i++)
    {
        listmax=i;
        for(j=i+1; j<=num-1; j++)
        {
            if(emp[j].hiredate.year==emp[listmax].hiredate.year)
            {
                if(emp[j].hiredate.month>emp[listmax].hiredate.month)
                {
                    listmax=j;
                }
            }
        }
        if(listmax!=i)
        {
            temp=emp[i];
            emp[i]=emp[listmax];
            emp[listmax]=temp;
        }
    }
    for(i=0; i<=num-2; i++)
    {
        listmax=i;
        for(j=i+1; j<=num-1; j++)
        {
            if(emp[j].hiredate.year==emp[listmax].hiredate.year)
            {
                if(emp[j].hiredate.month==emp[listmax].hiredate.month)
                {
                    if(emp[j].hiredate.day>emp[listmax].hiredate.day)
                    {
                        listmax=j;
                    }
                }
            }
        }
        if(listmax!=i)
        {
            temp=emp[i];
            emp[i]=emp[listmax];
            emp[listmax]=temp;
        }
    }
}

int Searchbyname(int num,struct Employ emp[])/**��Ա�����ֲ���**/
{
    int i;
    char que[MAX_NAMELINE];
    while(getchar()!='\n');
    gets(que);
    for(i=0; i<=num-1; i++)
    {
        if(strcmp(que,emp[i].name)==0)
        {
            return i;
        }
    }
    return -1;
}

int SearchbyID(int num,struct Employ emp[])/**��Ա������������**/
{
    int que,i,ret;
    while(getchar()!='\n');
    ret=scanf("%d",&que);
    while(ret!=1)
    {
        printf("Please input proper employee ID.\n");
        while(getchar()!='\n');
        ret=scanf("%d",&que);
    }
    for(i=0; i<=num-1; i++)
    {
        if(que==emp[i].ID)
        {
            return i;
        }
    }
    return -1;

}

int Searchbyhiredate(int num,EMPLOY emp[])/**����ְ���ڲ���**/
{
    int que1,que2,que3,i,ret;
    while(getchar()!='\n');
    ret=scanf("%d,%d,%d",&que1,&que2,&que3);
    while(ret!=3)
    {
        printf("Please input proper employee hiredate.\n");
        while(getchar()!='\n');
        ret=scanf("%d,%d,%d",&que1,&que2,&que3);
    }
    for(i=0; i<=num-1; i++)
    {
        if(que1==emp[i].hiredate.year)
        {
            if(que2==emp[i].hiredate.month)
            {
                if(que3==emp[i].hiredate.day)
                {
                    return i;
                }
            }
        }
    }
    return -1;
}

void Modify(int num,EMPLOY emp[])/**�޸�Ա������**/
{
    int ans,ret;
    float s;
    printf("Please input employee ID:");
    ans=SearchbyID(num,emp);
    while(ans==-1)
    {
        printf("NO FOUND! Please input employee ID again:");
        ans=SearchbyID(num,emp);
    }
    printf("The orignal salary is %.2f  Please input modified salary:",emp[ans].salary);
    while(getchar()!='\n');
    ret=scanf("%f",&s);
    while(ret!=1||s<5000-1e-5||s>20000+1e-5)
    {
        printf("Please input salary between 5000 and 20000:");
        while(getchar()!='\n');
        ret=scanf("%f",&s);
    }
    emp[ans].salary=s;
    printf("MODIFIED SUCCESSFULLY!\n");
}

float Sum(int num,EMPLOY emp[])/**��͹���**/
{
    int i;
    float sum=0;
    for (i=0; i<=num-1; i++)
    {
        sum+=emp[i].salary;
    }
    return sum;
}

void Inputstatis(STATIS sta)/**��ͳ�����ݸ��Ƶ��ļ���**/
{
    FILE *fp=NULL;
    if((fp=fopen("staff_statis.txt","w"))!=NULL)
    {
        fwrite(&sta,sizeof(STATIS),1,fp);
    }
    else
    {
        printf("FAIL TO OPEN FILE!\n");
        exit(1);

    }
    while((fclose(fp))!=0)
    {
        printf("FAIL TO CLOSE FILE!\n");
        exit(1);
    }
}
