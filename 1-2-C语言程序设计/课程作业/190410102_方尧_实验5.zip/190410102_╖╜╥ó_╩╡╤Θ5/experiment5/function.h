#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED
void PrintfChoice();
void InputDate(int num,int list[],double salary[]);
double Average(int num,double a[]);
void Order(int num,int a[],double b[]);
int Search(int num,int b[]);

#endif // FUNCTION_H_INCLUDED
