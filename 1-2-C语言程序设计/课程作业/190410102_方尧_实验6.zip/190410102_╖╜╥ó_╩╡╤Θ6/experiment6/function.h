#ifndef FUNCTION_H_INCLUDED
#define FUNCTION_H_INCLUDED
#define MAX_EMPLOYEE 30

void PrintfChoice();
void InputDate(int num,char name[],int idsalary[][2]);
double Average(int num,int a[][2]);
void Order(int num,char name[],int a[][2]);
int SearchbyID(int num,int a[][2]);
int Searchbyname(int num,char name[]);



#endif // FUNCTION_H_INCLUDED
